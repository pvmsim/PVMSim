# PV_DDM_Project

## Purpose
This repository implements a double-diode-model (DDM) fitting workflow for photovoltaic module I–V curves, including coarse and fine search stages and a final evaluation report using measured I–V data.

## Scope
- Model: Double-diode model with series resistance and shunt resistance.
- Objective: Minimize current RMSE between measured and simulated I–V points (full-curve).
- Stages: Coarse search → Fine search → Evaluation and reporting.

## Requirements
- MATLAB R20XXb (tested on: <R2025b>)
- Toolboxes (if any): <list or "none">
- OS: <Windows 11>

## Project Structure
- `config/modules/`  Module/datasheet scripts (e.g., `STP6_120_60.m`).
- `core/`            Optimization and fitting routines (coarse/fine).
- `model/`           DDM model evaluation and plotting functions.
- `data/iv/`         Measured I–V curves (input data).
- `pipeline/`        Orchestration scripts (main run entry points).
- `outputs/`         Fit results, logs, exported tables.
- `figures/`         Generated plots (I–V curves, convergence).

## Input Data Format
### Measured I–V curves
Place measured curves in `data/iv/`.

Expected columns for text files:
- Voltage [V]
- Current [A]

Example: `data/iv/Table6.txt`

Notes:
- The pipeline assumes V is in volts and I in amperes.
- The number of points is read from the file (no fixed length required).

## Configuration
### Module (datasheet)
Select the module script in `config/modules/` and ensure it defines at least:
- `Ns`, `Voc`, `Isc`, `Vmpp`, `Impp` (STC values)
- Any temperature constants required by the pipeline (if applicable)

### Key Parameters
- `n1`, `n2`: diode ideality factors (can be fixed or fitted depending on stage)
- `Io1`, `Io2`: diode saturation currents
- `Rs`, `Rsh`: series and shunt resistances
- `Iph`: photocurrent (optional variable; if not provided, defaults to Isc)

## How to Run
1) Add project root to MATLAB path.
2) Run the main entry point:

run_main

## License
- Source code: MIT License (see `LICENSE`).
- Example data and non-code assets (if provided): CC0 1.0 (see `LICENSE-CC0.txt`).
- Third-party notices: see `THIRD_PARTY_NOTICES.md`.
